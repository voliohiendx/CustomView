package com.example.custtomview

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class DrawPath
@JvmOverloads
constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {
    private var backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var measure = PathMeasure()
    private var pathScreen = Path()
    private var paddingView = 20f
    private var space2Point = 30f
    private var spaceY2NotchPoint = 100f

    private val listPoint = mutableListOf<PointF>()

    init {
        backgroundPaint.apply {
            color = Color.parseColor("#B0000000")
            strokeWidth = 5f
            style = Paint.Style.STROKE
        }
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        anim()
    }

    fun anim() {
        CoroutineScope(Dispatchers.Default).launch {
            while (true) {
                rotate += 5
                delay(16)
                postInvalidate()
            }
        }
    }

    val paint = Paint()
    var shader: LinearGradient? = null

    private var pos = FloatArray(2)
    private var distance = 0f
    private var rotate = 0f
    private var matrix2 = Matrix()
    var locationOfClustersOf3Points = 20f

    @SuppressLint("DrawAllocation")
    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        shader = LinearGradient(
            0f,
            0f,
            0f,
            height.toFloat(),
            Color.RED,
            Color.BLUE,
            Shader.TileMode.CLAMP
        )

        listPoint.clear()
        // notch ip <14
        //A:  x= paddingView, y= paddingView  corner= 180 leftToRight
        listPoint.addAll(drawPoint(PointF(paddingView, paddingView), corner_180, true))

        //B:  x= width / 3, y= paddingView  corner= 270 leftToRight
        listPoint.addAll(drawPoint(PointF((width / 3).toFloat(), paddingView), corner_270, true))

        //C:  x= width / 3, y= paddingView+ spaceY2NotchPoint  corner= 90 leftToRight
        listPoint.addAll(drawPoint(PointF((width / 3).toFloat(), paddingView+ spaceY2NotchPoint), corner_90, true))

        //D:  x= 2* width / 3, y= paddingView+ spaceY2NotchPoint  corner= 360 leftToRight
        listPoint.addAll(drawPoint(PointF((2*width / 3).toFloat(), paddingView+ spaceY2NotchPoint), corner_360, true))

        //E:  x= 2* width / 3, y= paddingView  corner= 180 leftToRight
        listPoint.addAll(drawPoint(PointF((2*width / 3).toFloat(), paddingView), corner_180, true))

        //F:  x= width -paddingView , y= paddingView  corner= 270 leftToRight
        listPoint.addAll(drawPoint(PointF(width -paddingView, paddingView), corner_270, true))

        //G:  x= width -paddingView , y= height-paddingView  corner= 360 RightToLeft
        listPoint.addAll(drawPoint(PointF(width -paddingView,  height-paddingView), corner_360, false))

        //H:  x=  paddingView , y= height-paddingView  corner= 90 RightToLeft
        listPoint.addAll(drawPoint(PointF( paddingView,  height-paddingView), corner_90, false))
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)

//        pathScreen.moveTo(listPoint[0].x, listPoint[0].y)
//        for (i in 1..23 ) {
//            if(i ==1&&i ==2){
//                if(i==2){
//                    pathScreen.quadTo(listPoint[i-2].x, listPoint[i-2].y, listPoint[i].x, listPoint[i].y, -90f,90f, true)
//
//                }
//            } else {
//                pathScreen.lineTo(listPoint[i].x, listPoint[i].y)
//            }
//
//        }
//        pathScreen.close()
        drawPath()
        measure = PathMeasure(pathScreen, false)
        val mm = measure.length / ((measure.length / space2Point).toInt())
        distance = 0f
        while (true) {
            if (distance > measure.length) break
            measure.getPosTan(distance, pos, null)
            //    canvas?.drawCircle(pos[0], pos[1], 10f, backgroundPaint)
            distance += mm
        }

        paint.shader = shader
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas?.drawPath(pathScreen, backgroundPaint)
        canvas?.save()
        matrix2.setRotate(rotate, width / 2f, height / 2f)
        canvas?.setMatrix(matrix2)
        canvas!!.drawCircle(width / 2f, height / 2f, 1000f, paint)
        canvas?.restore()
//
    }
    private var radius1 = 10
    private var radius2 = 50
    private var radius3 = 50
    private var spaceNoteW = 200
    private var spaceNoteH = 100

    private fun drawPath(){
        pathScreen.reset()
        pathScreen.moveTo(paddingView+radius1,paddingView)
        pathScreen.lineTo(width/2f-spaceNoteW/2f-radius2,paddingView)
        pathScreen.quadTo(width/2f-spaceNoteW/2f,paddingView,width/2f-spaceNoteW/2f,paddingView+radius2)
        pathScreen.lineTo(width/2f-spaceNoteW/2f,paddingView+spaceNoteH-radius3)
        pathScreen.quadTo(width/2f-spaceNoteW/2f,paddingView+spaceNoteH,width/2f-spaceNoteW/2f+radius3,paddingView+spaceNoteH)
        pathScreen.lineTo(width/2f+spaceNoteW/2f ,paddingView+spaceNoteH)
        pathScreen.quadTo(width/2f+spaceNoteW/2f ,paddingView+spaceNoteH,width/2f+spaceNoteW/2f,paddingView+spaceNoteH-radius3 )
    }

    fun drawPoint(pointOrigin: PointF, corner: Int, isLeftToRight: Boolean): List<PointF> {
        //point Center
        val listPointF = mutableListOf<PointF>()
        var pointLeft = PointF()
        var pointCenter = PointF()
        var pointRight = PointF()

        when (corner) {
            corner_90 -> {
                pointLeft = PointF(pointOrigin.x , pointOrigin.y- locationOfClustersOf3Points)
                pointCenter = PointF(
                    pointOrigin.x + locationOfClustersOf3Points / 2,
                    pointOrigin.y - locationOfClustersOf3Points / 2
                )

                pointRight = PointF(pointOrigin.x+ locationOfClustersOf3Points, pointOrigin.y)
            }

            corner_180 -> {
                pointLeft = PointF(pointOrigin.x, pointOrigin.y + locationOfClustersOf3Points)
                pointCenter =
                    PointF(
                        pointOrigin.x + locationOfClustersOf3Points / 2,
                        pointOrigin.y + locationOfClustersOf3Points / 2
                    )

                pointRight = PointF(pointOrigin.x + locationOfClustersOf3Points, pointOrigin.y)
            }

            corner_270 -> {
                pointLeft = PointF(pointOrigin.x - locationOfClustersOf3Points, pointOrigin.y)
                pointCenter = PointF(
                    pointOrigin.x - locationOfClustersOf3Points / 2,
                    pointOrigin.y + locationOfClustersOf3Points / 2
                )

                pointRight = PointF(pointOrigin.x, pointOrigin.y + locationOfClustersOf3Points)
            }

            corner_360 -> {
                pointRight = PointF(pointOrigin.x, pointOrigin.y - locationOfClustersOf3Points)

                pointCenter = PointF(
                    pointOrigin.x - locationOfClustersOf3Points / 2,
                    pointOrigin.y - locationOfClustersOf3Points / 2
                )

                pointLeft = PointF(pointOrigin.x - locationOfClustersOf3Points, pointOrigin.y)
            }
        }
        if (isLeftToRight) {
            listPointF.add(pointLeft)
            listPointF.add(pointCenter)
            listPointF.add(pointRight)
        } else {
            listPointF.add(pointRight)
            listPointF.add(pointCenter)
            listPointF.add(pointLeft)
        }
        return listPointF
    }

    companion object {
        const val corner_90 = 1
        const val corner_180 = 2
        const val corner_270 = 3
        const val corner_360 = 4
    }


}